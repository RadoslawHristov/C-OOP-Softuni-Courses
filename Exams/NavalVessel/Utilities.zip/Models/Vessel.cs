﻿using System;
using System.Collections.Generic;
using System.Text;
using NavalVessels.Models.Contracts;
using NavalVessels.Utilities.Messages;

namespace NavalVessels.Models
{
    public abstract class Vessel : IVessel
    {
        private string name;
        private ICaptain captain;
        private double armor;
        private double mainWeapon;
        private double speed;
        private ICollection<string> targets;

        protected Vessel(string name, double mainWeaponCaliber, double speed, double armorThickness)
        {
            Name = name;
            MainWeaponCaliber = mainWeaponCaliber;
            Speed = speed;
            ArmorThickness = armorThickness;
            Targets = new List<string>();
        }

        public string Name
        {
            get => name;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException(ExceptionMessages.InvalidVesselName);
                }

                name = value;
            }
        }

        public ICaptain Captain
        {
            get => captain;
            set
            {
                if (captain == null)
                {
                    throw new NullReferenceException(ExceptionMessages.InvalidCaptainToVessel);
                }

                captain = value;
            }
        }

        public double ArmorThickness
        {
            get => armor;
            set
            {
                this.armor = value;
            }
        }

        public double MainWeaponCaliber
        {
            get => mainWeapon;
            protected set
            {
                mainWeapon = value;
            }
        }

        public double Speed
        {
            get => speed;
            protected set
            {
                speed = value;
            }
        }

        public ICollection<string> Targets
        {
            get => targets;
            private set
            {
                targets = value;
            }
        }

        public virtual void Attack(IVessel target)
        {
            if (target == null)
            {
                throw new NullReferenceException(ExceptionMessages.InvalidTarget);
            }

            if (target.ArmorThickness - this.MainWeaponCaliber > 0)
            {
                target.ArmorThickness -= this.MainWeaponCaliber;
            }
            else if (target.ArmorThickness - this.MainWeaponCaliber <= 0)
            {
                target.ArmorThickness = 0;
            }
            this.Targets.Add(target.Name);
        }

        public virtual void RepairVessel()
        {
            this.ArmorThickness = ArmorThickness;
        }

        public override string ToString()
        {
            StringBuilder sv = new StringBuilder();
            sv.AppendLine($"- {Name}");
            sv.AppendLine($"*Type: {GetType().Name}");
            sv.AppendLine($"*Armor thickness: {this.ArmorThickness}");
            sv.AppendLine($"*Main weapon caliber: {this.MainWeaponCaliber}");
            sv.AppendLine($"*Speed: {this.Speed}  knots");
            if (Targets.Count == 0)
            {
                sv.AppendLine("None");
            }
            else
            {
                foreach (var target in Targets)
                {
                    sv.Append($"{target}, ");
                }
            }
            return sv.ToString().TrimEnd();
        }
    }
}
