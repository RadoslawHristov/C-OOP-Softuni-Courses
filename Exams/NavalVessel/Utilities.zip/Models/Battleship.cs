﻿using System;
using System.Collections.Generic;
using System.Text;
using NavalVessels.Models.Contracts;

namespace NavalVessels.Models
{
    public class Battleship : Vessel,IBattleship
    {
        private const double armorBydefhaut = 300;
        private bool sonarMode;
        public Battleship(string name, double mainWeaponCaliber, double speed) 
            : base(name, mainWeaponCaliber, speed, armorBydefhaut)
        {
        }

        public bool SonarMode
        {
            get => sonarMode;
            private set
            {
                sonarMode = value;
            }
        }

        public virtual void ToggleSonarMode()
        {
            if (SonarMode==false)
            {
                SonarMode = true;
            }
            else if(SonarMode==true)
            {
                SonarMode = false;
            }

            if (SonarMode==true)
            {
                MainWeaponCaliber += 40;
                Speed += 5;
            }

            if (SonarMode==false)
            {
                MainWeaponCaliber -= 40;
                Speed -= 5;
            }
        }

        public override void Attack(IVessel target)
        {
            base.Attack(target);
        }

        public override void RepairVessel()
        {
            this.ArmorThickness = armorBydefhaut;
        }

        public override string ToString()
        {
            StringBuilder sv = new StringBuilder();
            sv.AppendLine($"- {Name}");
            sv.AppendLine($"*Type: {GetType().Name}");
            sv.AppendLine($"*Armor thickness: {this.ArmorThickness}");
            sv.AppendLine($"*Main weapon caliber: {this.MainWeaponCaliber}");
            sv.AppendLine($"*Speed: {this.Speed}  knots");
            if (Targets.Count == 0)
            {
                sv.AppendLine("None");
            }
            else
            {
                foreach (var target in Targets)
                {
                    sv.Append($"{target}, ");
                }
            }

            if (SonarMode==true)
            {
                 sv.AppendLine($"*Sonar mode: {"ON"}");
            }
            else
            {
                sv.AppendLine($"*Sonar mode: {"OFF"}");
            }
           
            return sv.ToString().TrimEnd();
        }
    }
}
