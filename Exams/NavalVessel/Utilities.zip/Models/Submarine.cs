﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NavalVessels.Models.Contracts;

namespace NavalVessels.Models
{
    public class Submarine : Vessel, ISubmarine
    {
        private const double armorThick = 200;
        private bool submergeMode;
        public Submarine(string name, double mainWeaponCaliber, double speed)
            : base(name, mainWeaponCaliber, speed, armorThick)
        {
        }

        public bool SubmergeMode
        {
            get => submergeMode;
            private set
            {
                submergeMode = value;
            }
        }

        public virtual void ToggleSubmergeMode()
        {
            if (SubmergeMode == false)
            {
                SubmergeMode = true;
            }
            else if (SubmergeMode == true)
            {
                SubmergeMode = false;
            }

            if (SubmergeMode == true)
            {
                MainWeaponCaliber += 40;
                Speed += 5;
            }
            if (SubmergeMode == false)
            {
                MainWeaponCaliber -= 40;
                Speed -= 5;
            }
        }

        public override void RepairVessel()
        {
            this.ArmorThickness = armorThick;
        }

        public override void Attack(IVessel target)
        {
            base.Attack(target);
        }

        public override string ToString()
        {
            StringBuilder sv = new StringBuilder();
            sv.AppendLine($"- {Name}");
            sv.AppendLine($"*Type: {GetType().Name}");
            sv.AppendLine($"*Armor thickness: {this.ArmorThickness}");
            sv.AppendLine($"*Main weapon caliber: {this.MainWeaponCaliber}");
            sv.AppendLine($"*Speed: {this.Speed}  knots");
            if (Targets.Count == 0)
            {
                sv.AppendLine("None");
            }
            else
            {
                foreach (var target in Targets)
                {
                    sv.Append($"{target}, ");
                }
            }

            if (SubmergeMode == true)
            {
               sv.AppendLine($"*Submerge mode: {"ON"}");
            }
            else
            {
               sv.AppendLine($"*Submerge mode: {"OFF"}");
            }

            return sv.ToString().TrimEnd();
        }
    }
}
