﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Security;
using System.Text;
using NavalVessels.Models.Contracts;
using NavalVessels.Utilities.Messages;

namespace NavalVessels.Models
{
    public class Captain : ICaptain
    {
        private string name;
        private int combatExperience;
        private ICollection<IVessel> vessels;

        public Captain(string names)
        {
            FullName = names;
            vessels = new List<IVessel>();
        }
        public string FullName
        {
            get => name;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new NullReferenceException(ExceptionMessages.InvalidCaptainName);
                }

                name = value;
            }
        }

        public int CombatExperience
        {
            get => combatExperience;
            private set
            {
                combatExperience = value;
            }
        }

        public ICollection<IVessel> Vessels => vessels;

        public void AddVessel(IVessel vessel)
        {
            if (vessel == null)
            {
                throw new NullReferenceException(ExceptionMessages.InvalidVesselForCaptain);
            }
            vessels.Add(vessel);
        }

        public virtual void IncreaseCombatExperience()
        {
            
               
            if (Vessels.Any(x => x.Captain.Vessels == Vessels))// may be not working exactly
            {
                CombatExperience += 10;
            }
            // may be if refactorired
        }

        public string Report()
        {
            StringBuilder sv = new StringBuilder();

            if (Vessels.Count > 0)
            {
                sv.AppendLine($"{FullName} has {this.CombatExperience} combat experience and commands {this.Vessels.Count} vessels.");
                foreach (var ves in Vessels)
                {
                    sv.AppendLine($"- {ves.Name}");
                    sv.AppendLine($"* Type: {ves.GetType().Name}");
                    sv.AppendLine($"*Armor thickness: {ves.ArmorThickness}");
                    sv.AppendLine($"*Main weapon caliber: {ves.MainWeaponCaliber}");
                    sv.AppendLine($"*Speed: {ves.Speed} knots");
                    if (ves.Targets.Count == 0)
                    {
                        sv.AppendLine("None");
                    }
                    else
                    {
                        foreach (var target in ves.Targets)
                        {
                            sv.Append($"{target}, ");
                        }
                    }

                }
            }

            return sv.ToString().TrimEnd();
        }

       
    }
}
