﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using NavalVessels.Core.Contracts;
using NavalVessels.Models;
using NavalVessels.Models.Contracts;
using NavalVessels.Repositories;

namespace NavalVessels.Core
{
    public class Controller : IController
    {
        private VesselRepository repository=new VesselRepository();
        private ICollection<ICaptain> captsain=new List<ICaptain>();

      

        public string HireCaptain(string fullName)
        {
            if (captsain.Any(x => x.FullName == fullName))
            {
                return $"Captain {fullName} is already hired.";
            }

            var capt = new Captain(fullName);
            captsain.Add(capt);
            return $"Captain {fullName} is hired.";
        }

        public string ProduceVessel(string name, string vesselType, double mainWeaponCaliber, double speed)
        {
            bool isValid = false;

            if (repository.FindByName(name) == null)
            {
                isValid = true;
                if (vesselType == "Submarine")
                {
                    Submarine sub = new Submarine(name, mainWeaponCaliber, speed);
                    repository.Add(sub);
                }
                else if (vesselType == "Battleship")
                {
                    Battleship ship = new Battleship(name, mainWeaponCaliber, speed);
                    repository.Add(ship);
                }
                else
                {
                    return $"Invalid vessel type.";
                }
            }

            else if (isValid)
            {
                return $"{vesselType} {name} is manufactured with the main weapon caliber of " +
                       $"{mainWeaponCaliber} inches and a maximum speed of " +
                       $"{speed} knots.";
            }

            return $"{vesselType} vessel {name} is already manufactured.";

        }

        public string AssignCaptain(string selectedCaptainName, string selectedVesselName)
        {
            if (!captsain.Any(x => x.FullName == selectedCaptainName))
            {
                return $"Captain {selectedCaptainName} could not be found.";
            }
            else if (!captsain.Any(x => x.Vessels.Any(x => x.Name == selectedVesselName)))
            {
                return $"Vessel {selectedVesselName} could not be found.";
            }
            else if (captsain.Any(x => x.Vessels.Any(x => x.Captain.FullName != selectedCaptainName)))
            {
                return $"Vessel {selectedVesselName} is already occupied.";
            }

            return $"Captain {selectedCaptainName} command vessel {selectedVesselName}.";

            var sec = captsain.FirstOrDefault(x => x.FullName == selectedCaptainName);
            var vesels = repository.FindByName(selectedVesselName);
            sec.AddVessel(vesels);
        }

        public string CaptainReport(string captainFullName)
        {
            return captsain.FirstOrDefault(x => x.FullName == captainFullName).Report();
        }

        public string VesselReport(string vesselName)
        {
            return repository.FindByName(vesselName).ToString();
        }

        public string ToggleSpecialMode(string vesselName)
        {
            IVessel vessel = repository.FindByName(vesselName);
            if (vessel == null)
            {
                return $"Vessel {vesselName} could not be found.";
            }

            if (vessel.GetType().Name == "Battleship")
            {
                Battleship battleshipCast = (Battleship)vessel;
                //Battleship myVessel = (Battleship)vessels.FindByName(vesselName);
                battleshipCast.ToggleSonarMode();
                return $"Battleship {vesselName} toggled sonar mode.";
            }
            else
            {
                Submarine submarineCast = (Submarine)vessel;
                //Submarine myVessel = (Submarine)vessels.FindByName(vesselName);
                submarineCast.ToggleSubmergeMode();
                return $"Submarine {vesselName} toggled submerge mode.";
            }
        }

        public string AttackVessels(string attackingVesselName, string defendingVesselName)
        {
            var attackingVessel = repository.FindByName(attackingVesselName);
            var defendingVessel = repository.FindByName(defendingVesselName);
            if (attackingVessel == null || defendingVessel == null)
            {
                if (attackingVessel == null)
                {
                    return $"Vessel {attackingVesselName} could not be found.";
                }
                else
                {
                    return $"Vessel {defendingVessel} could not be found.";
                }
            }

            if (attackingVessel.ArmorThickness == 0 || defendingVessel.ArmorThickness == 0)
            {
                return $"Unarmored vessel {defendingVesselName} cannot attack or be attacked.";
            }


            attackingVessel.Attack(defendingVessel);
            attackingVessel.Captain.IncreaseCombatExperience();
            defendingVessel.Captain.IncreaseCombatExperience();
            return $"Vessel {defendingVesselName} was attacked by vessel {attackingVesselName} " +
                   $"- current armor thickness: {defendingVessel.ArmorThickness}.";
        }

        public string ServiceVessel(string vesselName)
        {
            var vessel = repository.FindByName(vesselName);
            if (vessel == null)
            {
                return $"Vessel {vesselName} could not be found.";
            }
            vessel.RepairVessel();
            return $"Vessel {vesselName} was repaired.";
        }
    }
}
