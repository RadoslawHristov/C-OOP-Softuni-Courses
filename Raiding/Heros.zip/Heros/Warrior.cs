﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Heros
{
    public class Warrior : BaseHero
    {
        public Warrior( string name) 
            : base( name)
        {
        }

        public override int Power => GlobalConstant.PaladinAndWarriorPower;

        public override string CastAbility()
        {
            return string.Format(GlobalConstant.StringOverrideRodueWarrior,GetType().Name,Name,Power);
        }
    }
}
