﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Heros
{
    public class Druid : BaseHero
    {
        public Druid( string name) 
            : base( name)
        {
        }

        public override int Power => GlobalConstant.RogueAndDruidPower;

        public override string CastAbility()
        {
            return string.Format(GlobalConstant.StringOverrideDruidPaladin, GetType().Name, Name,Power);
        }
    }
}
