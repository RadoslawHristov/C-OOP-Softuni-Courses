﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Heros
{
    public class Paladin : BaseHero
    {
        public Paladin( string name) 
            : base( name)
        {
        }

        public override int Power => GlobalConstant.PaladinAndWarriorPower;

        public override string CastAbility()
        {
            return string.Format(GlobalConstant.StringOverrideDruidPaladin,GetType().Name,Name,Power);
        }
    }
}
