﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Heros
{
    public class Rogue : BaseHero
    {
        public Rogue( string name)
            : base( name)
        {
        }

        public override int Power => GlobalConstant.RogueAndDruidPower;


        public override string CastAbility()
        {
            return string.Format(GlobalConstant.StringOverrideRodueWarrior,GetType().Name,Name,Power);
        }
    }
}
