﻿namespace BorderControl
{
    public interface IWhoIAm
    {
        public string Name { get; set; }

        public string Id { get; set; }
    }
}