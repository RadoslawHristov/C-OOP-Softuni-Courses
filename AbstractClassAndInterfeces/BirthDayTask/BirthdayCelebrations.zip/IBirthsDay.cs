﻿namespace BirthdayCelebrations
{
    public interface IBirthsDay
    {
        public string Name { get; set; }
        public string Birthday { get; set; }
    }
}