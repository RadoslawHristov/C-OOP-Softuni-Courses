﻿namespace FoodShortage
{
    public interface IBuyer_
    {
        public void BuyFood();
        public int Food { get; set; }
    }
}