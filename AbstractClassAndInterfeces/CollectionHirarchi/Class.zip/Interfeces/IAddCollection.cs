﻿namespace CollectionHierarchy.Interfeces
{
    public interface IAddCollection<T>
    {
        int Add(T element);
    }
}