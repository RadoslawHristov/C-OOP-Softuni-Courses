﻿using System;
using System.Collections.Generic;
using System.Text;
using PlayersandMonsters;

namespace PlayersAndMonsters
{
    public class DarkKnight : Knight
    {
        public DarkKnight(string username, int level) 
            : base(username, level)
        {
        }
    }
}
