﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.classes
{
    public class Seeds : Food
    {
        public Seeds(int quantity) 
            : base(quantity)
        {
        }
    }
}
